package CoreJavaasignments;

public class Q1Java {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello\nLavanya");
	}

}
