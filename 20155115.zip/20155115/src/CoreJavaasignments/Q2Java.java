package CoreJavaasignments;

public class Q2Java {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int res1 = -5 + 8 * 6; 
        System.out.println("" + res1); 
        int res2 = (55 + 9) % 9; 
        System.out.println("" + res2); 
        int res3 = 20 + -3 * 5 / 8; 
        System.out.println("" + res3); 
        int res4 = 5 + 15 / 3 * 2 - 8 % 3; 
        System.out.println("" + res4); 
	}

}
