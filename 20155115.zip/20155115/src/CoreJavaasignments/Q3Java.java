package CoreJavaasignments;

public class Q3Java {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
int num1 = 125;
int num2 = 24;
int res1 = num1 + num2;
System.out.println(res1);
int res2 = num1*num2;
System.out.println(res2);
int res3 = num1-num2;
System.out.println(res3);
int res4 = num1/num2;
System.out.println(res4);
int res5 = num1 % num2;
System.out.println(res5);
	
	}

}
