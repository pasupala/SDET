package CoreJavaasignments;

public class Q5Java {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=1;
int y=2;
//Before swap
System.out.println("Before Swapping : i = "+i+"\ty =" +y);
//Swap
i=i+y;
y=i-y;
i=i-y;
System.out.println("After Swapping  : i = "+i+"\ty =" +y);
	}

}
