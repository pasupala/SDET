package CoreJavaasignments;

public class Q4Java {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int num=8;
for(int i=1;i<11;i++)
{
	int res=num * i;
	System.out.println(num + "*" + i + "=" + res);
	
}
	
	}

}

