package sdetjava.task2;

public class Q6 {

    public static void main(String[] args) {
        String sentence = "M y  nam e i s lav  an  ya.";
        System.out.println("Original sentence: " + sentence);

        sentence = sentence.replaceAll("\\s", "");
        System.out.println("After replacement: " + sentence);
    }
}